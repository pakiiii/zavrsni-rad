from flask import Flask, render_template
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
import datetime

app = Flask(__name__)

@app.route('/')
def index():
    # Generiranje RSA privatnog i javnog ključa
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    public_key = private_key.public_key()

    # Dobivanje trenutnog vremena kao vremenskog žiga
    trenutni_vremenski_žig = datetime.datetime.now()

    # Formatiranje vremenskog žiga u željeni format (dan/mjesec/godina)
    formatirani_vremenski_žig = trenutni_vremenski_žig.strftime("%d/%m/%Y")

    # Nadodavanje sati, minuta i sekundi na formatirani vremenski žig
    formatirani_vremenski_žig += " " + trenutni_vremenski_žig.strftime("%H:%M:%S")

    # Potpisivanje vremenskog žiga
    data = formatirani_vremenski_žig.encode('utf-8')
    signature = private_key.sign(
        data,
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )

    # Provjera potpisa
    try:
        public_key.verify(
            signature,
            data,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        potpis_valjan = True
    except:
        potpis_valjan = False

    return render_template('index.html', vremenski_žig=formatirani_vremenski_žig, potpis_valjan=potpis_valjan)

if __name__ == '__main__':
    app.run(debug=True)
